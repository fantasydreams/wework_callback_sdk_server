---
title: "mg_hexdumpf()"
decl_name: "mg_hexdumpf"
symbol_kind: "func"
signature: |
  void mg_hexdumpf(FILE *fp, const void *buf, int len);
---

Same as mg_hexdump, but with output going to file instead of a buffer. 

